package fr.formation.formationdevops;

public class App {
    
    public static void main(String[] args) {
    }
    
}
